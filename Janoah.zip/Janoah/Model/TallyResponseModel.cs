﻿using Newtonsoft.Json;

namespace Janoah.Model
{
    public class TallyResponseModel
    {
        public string? eventId { get; set; }
        public DateTime createdAt { get; set; }
        public Data data { get; set; }
    }
    public class Data
    {
        public string? responseId { get; set; }
        public string? submissionId { get; set; }
        public string? respondentId { get; set; }
        public string? formId { get; set; }
        public string? formName { get; set; }
        public DateTime? createdAt { get; set; }
        public List<Field> fields { get; set; }
    }

    public class Field
    {
        public string? key { get; set; }
        public string? label { get; set; }
        public string? type { get; set; }
        public object? value { get; set; }
        public List<Option>? options { get; set; }
    }

    public class Option
    {
        public string? id { get; set; }
        public string? text { get; set; }
        public bool? isOtherOption { get; set; }
        public string? optionId { get; set; }
    }

    



}
