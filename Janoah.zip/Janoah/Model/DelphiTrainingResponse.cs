﻿namespace Janoah.Model
{
    public class DelphiTrainingResponse
    {
        public string Weakness { get; set; }
        public string[] TrainingSteps { get; set; }
    }
}
