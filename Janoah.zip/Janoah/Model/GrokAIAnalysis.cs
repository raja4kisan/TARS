﻿namespace Janoah.Model
{
    public class GrokAIAnalysis
    {
        public string[] Strengths { get; set; }
        public string[] Weaknesses { get; set; }
    }
}
