﻿using Janoah.Model;
using Janoah.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Janoah.Controller
{
    [Route("api/Tally")]
    [ApiController]
    public class TallyController : ControllerBase
    {
        private readonly GrokAIService _grokAIService;
        private readonly AIAnalysisService _aiAnalysisService;

        public TallyController(GrokAIService grokAIService, AIAnalysisService aiAnalysisService)
        {
            _grokAIService = grokAIService;
            _aiAnalysisService = aiAnalysisService;
        }

        //[HttpPost("webhook")]
        //public async Task<IActionResult> ReceiveTallyResponses([FromBody] TallyResponseModel response)
        //{
        //    if (response == null)
        //        return BadRequest("Invalid response data");

        //    var analysis = await _grokAIService.AnalyzeResponseAsync(response);
        //    return Ok(analysis);
        //}
        [HttpPost("webhook")]
        public async Task<IActionResult> ReceiveTallyResponses([FromBody] TallyResponseModel response)
        {
            if (response == null || response.data == null || response.data.fields == null)
                return BadRequest("Invalid response data");

            //var userResponses = response.data.fields.ToDictionary(f => f.label, f => f.value?.ToString() ?? string.Empty);
            var analysisWithTrainingPlan = await _aiAnalysisService.AnalyzeResponseAsync(response);

            return Ok(new { analysisWithTrainingPlan });
        }
    }
}
