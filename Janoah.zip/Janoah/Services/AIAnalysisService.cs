﻿using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Janoah.Model;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

public class AIAnalysisService
{
    private readonly HttpClient _httpClient;
    private readonly string _azureEndpoint;
    private readonly string _azureApiKey;
    private readonly string _azureDeployment;
    private readonly string _delphiEndpoint;

    public AIAnalysisService(HttpClient httpClient, IConfiguration configuration)
    {
        _httpClient = httpClient;
        _azureEndpoint = configuration["AzureOpenAI:Endpoint"];
        _azureApiKey = configuration["AzureOpenAI:ApiKey"];
        _azureDeployment = configuration["AzureOpenAI:DeploymentName"];
        _delphiEndpoint = configuration["DelphiAI:Endpoint"];

    }

    public async Task<string> AnalyzeResponseAsync(TallyResponseModel userResponses)
    {
        var systemPrompt = "Analyze the user's responses and identify strengths and weaknesses and Extract Strengths: and Weaknesses: without any character";
        var userMessage = System.Text.Json.JsonSerializer.Serialize(userResponses);

        /*string.Join("\n", userResponses.Select(kvp => $"{kvp.Key}: {kvp.Value}"));*/

        var requestData = new
        {
            messages = new[]
            {
                new { role = "system", content = systemPrompt },
                new { role = "user", content = userMessage }
            },
            temperature = 0.7,
            max_tokens = 500
        };

        var requestBody = JsonConvert.SerializeObject(requestData);
        var request = new HttpRequestMessage(HttpMethod.Post, $"{_azureEndpoint}/openai/deployments/{_azureDeployment}/chat/completions?api-version=2024-02-15-preview")
        {
            Content = new StringContent(requestBody, Encoding.UTF8, "application/json")
        };
        request.Headers.Add("api-key", _azureApiKey);

        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode)
        {
            throw new Exception("Error analyzing response with Azure ChatGPT.");
        }

        var jsonResponse = await response.Content.ReadAsStringAsync();
        dynamic result = JsonConvert.DeserializeObject(jsonResponse);
        string analysis = result.choices[0].message.content;

        // Extract weaknesses from analysis
        string weaknesses = ExtractWeaknesses(analysis);

        // Call Delphi AI for training recommendations
        //string trainingPlan = await GetTrainingPlanFromDelphi(weaknesses);

        return $"Your weaknesses are as follows:\n{weaknesses}";
    }
    private string ExtractWeaknesses(string analysis)
    {
        // Dummy implementation - refine based on Azure ChatGPT output format
        if (analysis.Contains("Weaknesses:") || analysis.Contains("Weaknesses:"))
        {
            return analysis.Split("Weaknesses:")[1].Trim();
        }
        return "No weaknesses identified.";
    }

    private async Task<string> GetTrainingPlanFromDelphi(string weaknesses)
    {
        var requestData = new { weaknesses = weaknesses };
        var requestBody = JsonConvert.SerializeObject(requestData);

        var request = new HttpRequestMessage(HttpMethod.Post, _delphiEndpoint)
        {
            Content = new StringContent(requestBody, Encoding.UTF8, "application/json")
        };

        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode)
        {
            return "Error retrieving training plan from Delphi AI.";
        }

        return await response.Content.ReadAsStringAsync();
    }
}