﻿using Janoah.Model;
using Newtonsoft.Json;
using System.Text;

namespace Janoah.Services
{
    public class GrokAIService
    {
        private readonly HttpClient _httpClient;

        public GrokAIService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<GrokAIAnalysis> AnalyzeResponseAsync(TallyResponseModel response)
        {
            var content = new StringContent(JsonConvert.SerializeObject(response), Encoding.UTF8, "application/json");
            var result = await _httpClient.PostAsync("https://grokai-api.com/analyze", content);

            if (!result.IsSuccessStatusCode)
                throw new Exception("Error analyzing response");

            var jsonResponse = await result.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<GrokAIAnalysis>(jsonResponse);
        }
    }
}
