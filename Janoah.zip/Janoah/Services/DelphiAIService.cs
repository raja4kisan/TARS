﻿using Janoah.Model;
using Newtonsoft.Json;
using System.Text;

namespace Janoah.Services
{
    public class DelphiAIService
    {
        private readonly HttpClient _httpClient;

        public DelphiAIService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<DelphiTrainingResponse> TrainUserAsync(string weakness)
        {
            var request = new { weaknesses = weakness };
            var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
            var result = await _httpClient.PostAsync("https://delphiai-api.com/train", content);

            if (!result.IsSuccessStatusCode)
                throw new Exception("Error retrieving training response");

            var jsonResponse = await result.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<DelphiTrainingResponse>(jsonResponse);
        }
    }
}
